#def arithmetic_arranger(problems):


    #return arranged_problems




#starting def
def too_many(x):
    if len(x) > 5:
        return True
    else:
        return False

def bad_operators(x):
    flag = 0
    for problem in x:
        if problem.find("*") > -1 or problem.find("/") > -1:
            flag += 1
            break
    
    if flag > 0:
        return True
    else:
        return False

def any_non_num(x):
    flag = 0
    for problem in x:
        if problem.find("+") > -1:
            y = problem.split("+")
            
        elif problem.find("-") > -1:
            y = problem.split("-")
            
        try:
            y[0] = int(y[0])
            y[1] = int(y[1])
        except:
            flag +=1
            break
    
    if flag > 0:
        return True
    else:
        return False

def five_digit_plus(x):
    for problem in x:
        if problem.find("+") > -1:
            y =  problem.replace(" ", "").split("+")
        elif problem.find("-") > -1:
            y = problem.replace(" ", "").split("-")
        
        if len(y[0]) > 4 or len(y[1]) > 4:
            return True
            break
        else: 
            return False
#end start def
def arrange_problems(x, compute = False):
    
    txt_combine = []
    
    for i, problem in enumerate(x):
        if problem.find("+") > -1:
            x[i] =  problem.replace(" ", "").split("+")
            x[i].insert(1, '+')
            
            if compute:
                res = int(x[i][0]) + int(x[i][2])
                
        elif problem.find("-") > -1:
            x[i] =  problem.replace(" ", "").split("-")
            x[i].insert(1, '-')
            
            if compute:
                res = int(x[i][0]) - int(x[i][2])

        
        if x[i].index(max(x[i], key=len)) == 0:
            l1 = len(x[i][0])
            l2 = 1 + l1 - len(x[i][2])
            r_s = ' ' * 4
            
            temp_list = []
            temp_list.append(' ' * 2 + x[i][0] + r_s)
            temp_list.append(x[i][1] + ' ' * l2 + x[i][2] + r_s)
            temp_list.append('-'*(l1+2) + r_s)
            
            if compute:
                l3 = len(temp_list[0]) - len(r_s) - len(str(res))
                temp_list.append(' ' * l3 + str(res) + r_s)
            
            txt_combine.append(temp_list)
            
        else:
            l1 = len(x[i][2])
            l2 = 2 + l1 - len(x[i][0])
            r_s = ' ' * 4
            
            temp_list = []
            temp_list.append(' ' * l2 + x[i][0] + r_s)
            temp_list.append(x[i][1] + ' ' + x[i][2] + r_s)
            temp_list.append('-'*(l1+2) + r_s)
            
            if compute:
                l3 = len(temp_list[0]) -len(r_s) - len(str(res))
                temp_list.append(' ' * l3 + str(res) + r_s)
            
            txt_combine.append(temp_list)
    

    resultant=""
    for i in range(len(txt_combine[0])):
        for j in range(len(txt_combine)):
            resultant = "".join((resultant, txt_combine[j][i]))

        resultant = resultant.rstrip(' ')
        if i != len(txt_combine[0])-1:
            resultant = "".join((resultant,"\n"))
    print(resultant)
    
    return resultant

def arithmetic_arranger(problems, compute = False):
#start checks    
    # Check length
    if too_many(problems):
        arranged_problems = "Error: Too many problems."
        
    # Check incorrect operators
    elif bad_operators(problems):
        arranged_problems = "Error: Operator must be '+' or '-'."
        
    # Check only numbers
    elif any_non_num(problems):
        arranged_problems = "Error: Numbers must only contain digits."
    
    # Check more than 4 digits
    elif five_digit_plus(problems):
        arranged_problems = "Error: Numbers cannot be more than four digits."
        
    # No issues found
    else:
      if compute:
        arranged_problems = arrange_problems(problems, compute)
      else:
        arranged_problems = arrange_problems(problems)

    return arranged_problems#